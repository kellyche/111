﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chepraga
{
    public class SourceOfPower
    {
        int currentattack;
        int attackup;
        int maxuse;
        int currentuse;
    }
    public int Attackup()
    {
        get { return attackup; }
        set { attackup = value; }
    }
    public int Maxuse()
    {
        get { return maxuse; }
        set { maxuse = value; }
    }
    public int Currentattack()
    {
        return currentattack + 1
    }

}
